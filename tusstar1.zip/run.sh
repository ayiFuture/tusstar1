export PATH=$PATH:/var/nodejs/bin
node main.js