const Config = {
    Hostname: "0.0.0.0",
    Port: 80,
    WebDir: "E:\\TusStar\\前台系统项目\\tusstar1\\web",
};
module.exports = Config;